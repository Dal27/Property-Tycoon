/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 */
public class incomeTax extends space{

    private String name = "Income Tax";
    private int location = 4;
    
    
    @Override
    public void exec(player x, player bank)
    {
        x.changeCash(-200);
        bank.changeCash(200);
    }
}
