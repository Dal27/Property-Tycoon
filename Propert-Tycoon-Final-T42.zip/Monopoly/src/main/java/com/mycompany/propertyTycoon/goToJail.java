package com.mycompany.propertyTycoon;


/**
 *
 * @author Team 42
 * A class specifically designed for a space on the board where
 * the player landing on it must go to jail without passing Go
 */
public class goToJail extends space{
    
    public int spaceType = 1;
    public int location = 30;

    /**
     * The player who has landed on the space, is sent to jail and does not pass Go
     * @param x     The player who has landed on the space and must interact with it
     * @param bank  The banker who controls how the player interacts with the space
     */
    @Override
    public void exec(player x,player bank)
    {
        x.goToJail();
    }
}
