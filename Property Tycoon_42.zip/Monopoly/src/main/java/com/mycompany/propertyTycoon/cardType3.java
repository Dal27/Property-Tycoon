/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * move forward to a position
 */
public class cardType3 extends card{
    
    private final int location;
        
    public cardType3(int x,String s)
    {
        location = x;
        setDesc(s);
    }
    
    @Override
    public void exec(player x,player bank,int location, freeParking FreeParking)
    {
        int xLocation = x.getLocation();
        
        if(xLocation <= location)
        {
            x.move(location - xLocation);
        }
        else
        {
            x.move(40 - xLocation + location);
        }
    }           
}
