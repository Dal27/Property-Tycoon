
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * A class specifically designed for a space on the board where
 * the player landing on it must pick up a opportunity knocks card and
 * complete the action stated by the card
 */
public class opportunityKnocks extends space{
    
    private int spaceType = 3;
    
    @Override
    public void exec(player x, player bank)
    {
        
    }
    
}
