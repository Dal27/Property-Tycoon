
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * A class specifically designed for a space on the board where
 * the player landing on it must pick up a pot luck card and
 * complete the action stated by the card
 */
public class potLuck extends space{
   
    private int spaceType = 2;
    private String name = "Pot Luck";

    /**
     * Constructor for the space on the board
     */
    public potLuck()
    {
        
    }

    @Override
    public void exec(player x, player bank)
    {
        
    }
}
