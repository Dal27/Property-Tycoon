package com.mycompany.propertyTycoon;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Team 42
 */
public class property extends space {

    private player owner;
    private static int price;
    private int rentValue = houseRentValue0;
    private static int housePrice;
    private static int houseRentValue0;
    private static int houseRentValue1;
    private static int houseRentValue2;
    private static int houseRentValue3;
    private static int houseRentValue4;
    private static int houseRentValue5;
    private int house = 0;
    private final int spaceType = 1;
    
    public property(String Name, int Price,int HousePrice,int HouseRentValue0,int HouseRentValue1,int HouseRentValue2,int HouseRentValue3,int HouseRentValue4,int HouseRentValue5)
    {
        this.setName(Name);
        price = Price;
        housePrice = HousePrice;
        houseRentValue0 = HouseRentValue0;
        houseRentValue1 = HouseRentValue1;
        houseRentValue2 = HouseRentValue2;
        houseRentValue3 = HouseRentValue3;
        houseRentValue4 = HouseRentValue4;
        houseRentValue5 = HouseRentValue5;
    }
    
    public int getPrice()
    {
        return price;
    }
    
    public int getRentValue()
    {
        return rentValue;
    }    
    
    public void buildHouse()
    {

        switch(house)
        {
            case 1:
                rentValue = houseRentValue1;
                house ++;
                owner.changeCash(-housePrice);
            case 2:
                rentValue = houseRentValue2;
                house ++;
                owner.changeCash(-housePrice);
            case 3:
                rentValue = houseRentValue3;
                house ++;
                owner.changeCash(-housePrice);
            case 4:
                rentValue = houseRentValue4;
                house ++;
                owner.changeCash(-housePrice);
            case 5:
                rentValue = houseRentValue5;
                house ++;
                owner.changeCash(-housePrice);            
        }

    }
    
    public void changeOwner(player x)
    {
        owner = x;
    }
            
    @Override
    public void exec(player x, player bank)
    {
        if(owner == bank)
        {
            try {
                x.buyProperty(this);
            } catch (Exception ex) {
                Logger.getLogger(property.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            x.changeCash(-rentValue);
            owner.changeCash(rentValue);
        }
    }
}
