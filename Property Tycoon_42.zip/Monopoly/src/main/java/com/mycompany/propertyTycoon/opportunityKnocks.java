/*
 * 
 * 
 */
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 */
public class opportunityKnocks extends space{
    
    private int spaceType = 3;
    
    @Override
    public void exec(player x, player bank)
    {
        
    }
    
}
