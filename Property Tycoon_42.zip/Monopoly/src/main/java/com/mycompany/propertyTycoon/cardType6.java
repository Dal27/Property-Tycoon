/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * pay fine
 */
public class cardType6 extends card{
    
    private final int fine;
   
    public cardType6(int x,String s)
    {
        fine = x;
        setDesc(s);
    }
    
    @Override
    public void exec(player x,player bank,int location, freeParking FreeParking)
    {
        x.changeCash(-fine);
        FreeParking.addFine(fine);
    }
}
