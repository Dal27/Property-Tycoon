package com.mycompany.propertyTycoon;

import java.util.Scanner;

/**
 *
 * @author Team 42
 */

public class player {
    private int location = 0;
    private int cash = 1500;
    private boolean completeOneCircuit = false;
    private int playerNo;
    private boolean jailFreeCard = false;
    private int jailTime = 0;
    private boolean isFined = false;
    
    public player(int PlayerNo)
    {
        playerNo = PlayerNo;
    }        
    
    public int getCash()
    {
        return cash;
    }
           
    public void changeCash(int x)
    {
        cash = cash + x;
    }
    
    public int getLocation()
    {
        return location;
    }
    
    public void move(int x)
    {        
        location = location + x;
        if(location >= 50)
        {
            location = location - 50;
            cash = cash + 200;
            completeOneCircuit = true;
        }        
    }
    
    public void moveTo(int x)
    {
        location = x;
    }
    
    public void changeJailTime(int x)
    {
        jailTime = jailTime + x;
    }
    
    public int getJailTime()
    {
        return jailTime;
    }
    
    public boolean hasJailCard()
    {
        return jailFreeCard;
    }
    
    public void changeJailCard(boolean x)
    {
        jailFreeCard = x;
    }
    
    public void goToJail()
    {
        moveTo(10);
        if(hasJailCard() == false)
        {
            changeJailTime(3);            
        }
        else
        {
            changeJailCard(false);
        }
    }
    
    public boolean buyProperty(property x) throws Exception 
    {       
        boolean choose = new Scanner(System.in).nextBoolean();
        System.out.println("Do you want to buy the property?");
        if(choose == true)
        { 
            if(completeOneCircuit == true)
            {
                if(x.getPrice() < cash){
                    x.changeOwner(this);
                    changeCash(- x.getPrice());
                    return true;
                }
                else
                {
                    throw new Exception("You don't have enough cash to buy this property. ");
                }            
            }
            else
            {
                throw new Exception("You are not able to buy a property until complete one circuit. ");
            }
        }
        return false;
    }
    
    public void sellProperty(property x, player bank)
    {
        x.changeOwner(bank);
        cash = cash + x.getPrice();
    }
    
    public int bid() throws Exception
    {
        if(completeOneCircuit == true)
        {
            int bidCash = new Scanner(System.in).nextInt();
            System.out.println("Enter bid");           
            if(bidCash < cash)
            {
                return bidCash;
            }
            else
            {
                throw new Exception("You don't have enough cash to make the bid.");
            }            
        }
        return 0;
    }
}
