
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 */
public class space {
    
    private static int location;
    private String name;
    private int spaceType;
    
    public void setLocation(int Location)
    {
        location = Location;
    }
    
    public void setName(String Name)
    {
        name = Name;
    }
    
    public void setSpaceType(int x)
    {
        spaceType = x;
    }
    
    public int getSpaceType()
    {
        return spaceType;
    }
    
    public void exec(player x,player bank)
    {
        
    }
}
