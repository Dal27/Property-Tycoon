package com.mycompany.propertyTycoon;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Team 42
 */
public class goToJail extends space{
    
    public int spaceType = 1;
    public int location = 30;
    
    @Override
    public void exec(player x,player bank)
    {
        x.goToJail();
    }
}
