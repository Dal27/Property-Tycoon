
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * This is an abstract class type that encompasses all cards within the game
 */
public class card {
    
    private String desc;

    /**
     * An abstract method that will be used to override for other card types
     * It executes the attributes of the card onto the given player
     * @param x             The amount of money to give/deduct
     * @param bank          The banker that is involved with the transaction between players
     * @param location      Transport the user to a given tile
     * @param FreeParking   A new freeparking is created for each card that must add money to the pile
     */
    public void exec(player x,player bank,int location, freeParking FreeParking)
    {
        
    }
    /**
     * An abstract method that will be used to override for other card types
     * @param d A description is given to the card to ensure players are immersed
     */
    public void setDesc(String d)
    {
        desc = d;
    }
}
