
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * An abstract class that represents all of the real estate  on the board
 */
public class space {
    
    private static int location;
    private String name;
    private int spaceType;

    /**
     * The method will set the location of the given real estate that wishes to take the space
     * @param Location The location on the board where the space will be located
     */
    public void setLocation(int Location)
    {
        location = Location;
    }

    /**
     * The method will set the name of the real estate that will take the space
     * @param Name The name of real estate
     */
    public void setName(String Name)
    {
        name = Name;
    }

    /**
     * The method will categories the types of spaces
     * @param x The type (category) of the space itself
     */
    public void setSpaceType(int x)
    {
        spaceType = x;
    }

    /**
     * The method collects the type of space
     * @return spaceType    the type of the space
     */
    public int getSpaceType()
    {
        return spaceType;
    }

    /**
     * An abstract method that will be used to override for other space types
     * @param x     The player who has landed on the space and must interact with it
     * @param bank  The banker who controls how the player interacts with the space
     */
    public void exec(player x,player bank)
    {
        
    }
}
