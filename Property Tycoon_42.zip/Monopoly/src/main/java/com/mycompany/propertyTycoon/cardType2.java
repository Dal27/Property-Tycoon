package com.mycompany.propertyTycoon;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Team 42
 * change location
 */
public class cardType2 extends card{
        
    private final int location;
        
    public cardType2(int x,String s)
    {
        location = x;
        this.setDesc(s);
    }
    
    @Override
    public void exec(player x,player bank,int location, freeParking FreeParking)
    {
        x.moveTo(location);
    }           
}

