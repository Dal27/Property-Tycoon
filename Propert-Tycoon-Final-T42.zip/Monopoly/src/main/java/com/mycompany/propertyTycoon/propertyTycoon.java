
package com.mycompany.propertyTycoon;

import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Team 42
 * the class where the game is essentially run and all the components of the game is combined
 * to create a working Property Tycoon
 */
public class propertyTycoon {

    private boolean isDouble = false;
    private game game;
    private ArrayList<player>players;
    private player bank;

    /**
     * Initialising the game upon start-up, ensuring all players are accounted for with the correct amount of money, including the bank
     */
    public propertyTycoon()
    {
        bank = new player(9);
        bank.changeCash(48500);
        int playerNum = new Scanner(System.in).nextInt();
        System.out.println("Type number of player");        
        for(int i = 0; i < playerNum; i++)
        {
            players.add(new player(i));
        }        
    }

    /**
     * Rolling of the dice at the start of a player's round
     * If the player rolls a double they receive an extra turn
     * If the player rolls a double they receive and extra turn
     * If a player rolls three doubles they are sent to jail
     * The dice dictates the amount of spaces the player moves forward
     * @param x The player that is rolling the dice
     */
    public void rollDice(player x)
    {  
        if(x.getJailTime() > 0)
        {
            x.changeJailTime(-1);
            return;
        }               
        Random r = new Random();
        int a = r.nextInt(7);
        int b = r.nextInt(7); 
        if((a+b)%2 == 0)
        {
            if(isDouble == false)
            {
                x.move(a+b);
                isDouble = true;
                game.board.get(x.getLocation()).exec(x,bank);
                rollDice(x);                
            }
            else
            {
                x.moveTo(11);
                isDouble = false;
            }
        }
        else
        {
            x.move(a+b);
            isDouble = false;
            game.board.get(x.getLocation()).exec(x,bank);
        }
    }

    /**
     * Depending on the space that the player lands on, the space is triggered and the actions for landing
     * on the specific space are executed
     * @param x The player that is on the space
     * @param y The space that the player is on
     */
    public void execSpace(player x, space y)
    {
        switch(y.getSpaceType())
        {
            case 1:
                game.board.get(x.getLocation()).exec(x,bank);
            
            case 2:
                drawLuckCard(x,bank);
                
            case 3:
                drawOppoCard(x,bank);                                                            
        }
    }

    /**
     * The auctioning of a property on the board when the player who has landed on it cannot afford it
     * players take turns to bid, the highest bidder is given ownership of the property
     * @param x The property that is being auctioned
     * @return The player that has won the auction
     * @throws Exception
     */
    public player bid(property x) throws Exception
    {
        int[] bidCash = null;
        for (int i = 0; i < players.size(); i++) 
        {                        
            bidCash[i] = players.get(i).bid();
        }
        int temp = 0;
        for (int j = 0; j + 1 < bidCash.length; j++)
        {
            for(int k = j + 1; k < bidCash.length; k++)
            {
                if(bidCash[j] < bidCash[k])
                {
                    temp = k;
                }           
            }
        }
        player win = players.get(temp);
        win.changeCash(-bidCash[temp]);
        x.changeOwner(win);
        return win;
    }

    /**
     * Draws a card from the pot luck deck and the player does as the card indicates
     * The card is placed at the bottom of the pile
     * @param x The player that has landed on the pot luck space
     * @param bank The banker that controls the game
     */
    public void drawLuckCard(player x, player bank)
    {
        card c = game.luckDeck.pop();
        c.exec(x,bank,x.getLocation(),new freeParking());
        game.luckDeck.addLast(c);       
    }

    /**
     * Draws a card from the opportunity knocks deck and the player does as the card indicates
     * The card is placed at the bottom of the pile
     * @param x The player that has landed on the opportunity knocks space
     * @param bank The banker that controls the game
     */
    public void drawOppoCard(player x,player bank)
    {
        card c = game.oppoDeck.pop();
        c.exec(x,bank,x.getLocation(),new freeParking());
        game.oppoDeck.addLast(c);
    }    
}

