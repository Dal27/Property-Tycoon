/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 */
public class freeParking extends space{
    
    private int fine = 0;
    private String name = "Free Parking";
    private int location = 20;
    private int spaceType = 1;
    
    public void addFine(int x)
    {
        fine = fine + x;
    }
    @Override
    public void exec(player x, player bank)
    {
        x.changeCash(fine);
        fine = 0;
    }
    
}
