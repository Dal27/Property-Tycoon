
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 *   This is a class that is utilised as an abstract class to provide attributes to
 *  opportunity knocks and pot luck cards, specifically cards where the player is expected to pay a fine
 */
public class cardType6 extends card{
    
    private final int fine;
    /**
     * A constructor for this specific type of card
     * @param x The amount of money to deduct
     * @param s A description is given to the card to ensure players are immersed
     */
    public cardType6(int x,String s)
    {
        fine = x;
        setDesc(s);
    }
    /**
     * Overrides the abstract class "card"
     * It executes the attributes of the card onto the given player
     * It deducts the amount of money from the player as given on the card
     * @param x             The amount of money to deduct
     * @param bank          The banker that is involved with taking money from the bank and handing to the player
     * @param location      Transport the user to a given tile
     * @param FreeParking   A new freeparking is created for each card that must add money to the pile
     */
    @Override
    public void exec(player x,player bank,int location, freeParking FreeParking)
    {
        x.changeCash(-fine);
        FreeParking.addFine(fine);
    }
}
