package com.mycompany.propertyTycoon;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Team 42
 * This class represents all property in the game
 */
public class property extends space {

    private player owner;
    private static int price;
    private int rentValue = houseRentValue0;
    private static int housePrice;
    private static int houseRentValue0;
    private static int houseRentValue1;
    private static int houseRentValue2;
    private static int houseRentValue3;
    private static int houseRentValue4;
    private static int houseRentValue5;
    private int house = 0;
    private final int spaceType = 1;

    /**
     * A constructor for all property on the board
     * @param Name              name of the property
     * @param Price             price of the property
     * @param HousePrice        price to place houses on property
     * @param HouseRentValue0   the rent that must be paid by an opposing player landing on the property
     * @param HouseRentValue1   the rent that must be paid by an opposing player landing on the property with 1 house
     * @param HouseRentValue2   the rent that must be paid by an opposing player landing on the property with 2 house
     * @param HouseRentValue3   the rent that must be paid by an opposing player landing on the property with 3 house
     * @param HouseRentValue4   the rent that must be paid by an opposing player landing on the property with 4 house
     * @param HouseRentValue5   the rent that must be paid by an opposing player landing on the property with 5 house
     */
    public property(String Name, int Price,int HousePrice,int HouseRentValue0,int HouseRentValue1,int HouseRentValue2,int HouseRentValue3,int HouseRentValue4,int HouseRentValue5)
    {
        this.setName(Name);
        price = Price;
        housePrice = HousePrice;
        houseRentValue0 = HouseRentValue0;
        houseRentValue1 = HouseRentValue1;
        houseRentValue2 = HouseRentValue2;
        houseRentValue3 = HouseRentValue3;
        houseRentValue4 = HouseRentValue4;
        houseRentValue5 = HouseRentValue5;
    }

    /**
     * Method attains the price of the property
     * @return returns the price to purchase the property
     */
    public int getPrice()
    {
        return price;
    }

    /**
     * The value of the rent is the amount that must be paid by players landing on it
     * @return returns the rent that must be paid by landing on it
     */
    public int getRentValue()
    {
        return rentValue;
    }

    /**
     * Building a house on the property.
     * the amount of houses on the property are first figured out,
     * and one additional house is placed, taking the amount of necessary money from
     * the players account
     */
    public void buildHouse()
    {

        switch(house)
        {
            case 1:
                rentValue = houseRentValue1;
                house ++;
                owner.changeCash(-housePrice);
            case 2:
                rentValue = houseRentValue2;
                house ++;
                owner.changeCash(-housePrice);
            case 3:
                rentValue = houseRentValue3;
                house ++;
                owner.changeCash(-housePrice);
            case 4:
                rentValue = houseRentValue4;
                house ++;
                owner.changeCash(-housePrice);
            case 5:
                rentValue = houseRentValue5;
                house ++;
                owner.changeCash(-housePrice);            
        }

    }

    /**
     * Switches ownership of a given property
     * @param x The player x is given ownership of the property
     */
    public void changeOwner(player x)
    {
        owner = x;
    }

    /**
     * When a player lands on the property, an attempt is made to buy the property
     * If another player owns the property, the appropriate rent is paid
     * @param x     The player who has landed on the space and must interact with it
     * @param bank  The banker who controls how the player interacts with the space
     */
    @Override
    public void exec(player x, player bank)
    {
        if(owner == bank)
        {
            try {
                x.buyProperty(this);
            } catch (Exception ex) {
                Logger.getLogger(property.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            x.changeCash(-rentValue);
            owner.changeCash(rentValue);
        }
    }
}
