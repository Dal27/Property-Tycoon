package com.mycompany.propertyTycoon;

import java.util.Scanner;

/**
 *
 * @author Team 42
 * This class encompases all of the attributes that can be applied to the player,
 * and the actions that they can take as a player
 */

public class player {
    private int location = 0;
    private int cash = 1500;
    private boolean completeOneCircuit = false;
    private int playerNo;
    private boolean jailFreeCard = false;
    private int jailTime = 0;
    private boolean isFined = false;

    /**
     * Identifies the player
     * @param PlayerNo Identifier
     */
    public player(int PlayerNo)
    {
        playerNo = PlayerNo;
    }

    /**
     * The amount of cash the payer holds
     * @return Cash held by player
     */
    public int getCash()
    {
        return cash;
    }

    /**
     * Allows the game to give/deduct money from the players account
     * @param x an amount of cash
     */
    public void changeCash(int x)
    {
        cash = cash + x;
    }

    /**
     *
     * @return Location of the player in the current state
     */
    public int getLocation()
    {
        return location;
    }

    /**
     * Allows for the player to move after the dice has been rolled
     * @param x an amount of spaces dictated by a dice
     */
    public void move(int x)
    {        
        location = location + x;
        if(location >= 50)
        {
            location = location - 50;
            cash = cash + 200;
            completeOneCircuit = true;
        }        
    }

    /**
     * Moves the player to a specific location on the board
     * @param x a space on the board
     */
    public void moveTo(int x)
    {
        location = x;
    }

    /**
     * Changes the amount of time that the user is in jail for
     * @param x number to add/deduct time
     */
    public void changeJailTime(int x)
    {
        jailTime = jailTime + x;
    }

    /**
     *
     * @return time to be spent in jail
     */
    public int getJailTime()
    {
        return jailTime;
    }

    /**
     *
     * @return whether the player holds a get out of jail free card
     */
    public boolean hasJailCard()
    {
        return jailFreeCard;
    }

    /**
     * gives/deducts get out of jail free cards from the user
     * @param x changes whether the player has a get out of jail free card or not
     */
    public void changeJailCard(boolean x)
    {
        jailFreeCard = x;
    }

    /**
     * Send the player to jail if the player does not hold a get out of jail free card
     * In jail for 3 turns
     */
    public void goToJail()
    {
        moveTo(10);
        if(hasJailCard() == false)
        {
            changeJailTime(3);            
        }
        else
        {
            changeJailCard(false);
        }
    }

    /**
     * The process of purchasing a property from the bank
     * @param x the property in question
     * @return  if the player was able to buy the property return true, else false
     * @throws Exception
     */
    public boolean buyProperty(property x) throws Exception 
    {       
        boolean choose = new Scanner(System.in).nextBoolean();
        System.out.println("Do you want to buy the property?");
        if(choose == true)
        { 
            if(completeOneCircuit == true)
            {
                if(x.getPrice() < cash){
                    x.changeOwner(this);
                    changeCash(- x.getPrice());
                    return true;
                }
                else
                {
                    throw new Exception("You don't have enough cash to buy this property. ");
                }            
            }
            else
            {
                throw new Exception("You are not able to buy a property until complete one circuit. ");
            }
        }
        return false;
    }

    /**
     * selling of a given property
     * @param x the property at hand
     * @param bank  the player who controls the ownership of the property (banker)
     */
    public void sellProperty(property x, player bank)
    {
        x.changeOwner(bank);
        cash = cash + x.getPrice();
    }

    /**
     * The action of bidding on a property when it is in the state of an auction
     * If the player is the highest bidder, they attain the property
     * @return  the amount of money the player wishes to bid
     * @throws Exception
     */
    public int bid() throws Exception
    {
        if(completeOneCircuit == true)
        {
            int bidCash = new Scanner(System.in).nextInt();
            System.out.println("Enter bid");           
            if(bidCash < cash)
            {
                return bidCash;
            }
            else
            {
                throw new Exception("You don't have enough cash to make the bid.");
            }            
        }
        return 0;
    }
}
