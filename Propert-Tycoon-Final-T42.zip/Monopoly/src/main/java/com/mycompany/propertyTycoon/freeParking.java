
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * A class specifically designed for a space on the board where
 * all money from fines are accumulated and any player which lands
 * on the space is able to collect the money that has accumulated
 */
public class freeParking extends space{
    
    private int fine = 0;
    private String name = "Free Parking";
    private int location = 20;
    private int spaceType = 1;

    /**
     * When a player is fined, the amount of money is added to free parking
     * @param x The amount of money that has been collected from the fine
     */
    public void addFine(int x)
    {
        fine = fine + x;
    }

    /**
     * The player is able to pick up all of the money accumulated and the money in
     * free parking is reset to 0
     * @param x     The player who has landed on the space and must interact with it
     * @param bank  The banker who controls how the player interacts with the space
     */
    @Override
    public void exec(player x, player bank)
    {
        x.changeCash(fine);
        fine = 0;
    }
    
}
