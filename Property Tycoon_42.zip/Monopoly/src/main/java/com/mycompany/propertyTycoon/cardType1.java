
package com.mycompany.propertyTycoon;


/**
 *
 * @author Team 42
 * changeMoney
 */
public class cardType1 extends card{
        
    private final int cash;
        
    public cardType1(int x,String s)
    {
        cash = x;
        this.setDesc(s);
    }
    
    @Override
    public void exec(player x,player bank,int location, freeParking FreeParking)
    {
        x.changeCash(cash);
        bank.changeCash(-cash);
    }           
}
