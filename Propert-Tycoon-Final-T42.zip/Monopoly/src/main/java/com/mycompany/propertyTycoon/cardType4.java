
package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 *   This is a class that is utilised as an abstract class to provide attributes to
 *  opportunity knocks and pot luck cards, specifically the card where the player is sent to jail
 */
public class cardType4 extends card{
    /**
     * A constructor for this specific type of card
     * @param s A description is given to the card to ensure players are immersed
     */
    public cardType4(String s)
    {
        setDesc(s);
    }
    /**
     * Overrides the abstract class "card"
     * It executes the attributes of the card onto the given player
     * It sends the player receiving the card straight to jail
     * @param x             The amount of money to give
     * @param bank          The banker that is involved with taking money from the bank and handing to the player
     * @param location      Transport the user to a given tile
     * @param FreeParking   A new freeparking is created for each card that must add money to the pile
     */
    @Override
    public void exec(player x,player bank,int location,freeParking FreeParking)
    {
        x.goToJail();
    }
}
