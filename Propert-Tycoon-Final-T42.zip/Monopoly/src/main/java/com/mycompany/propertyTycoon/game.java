
package com.mycompany.propertyTycoon;

import java.util.ArrayList;
import java.util.Deque;

/**
 *
 * @author Team 42
 */
public class game {
    
    public Deque<card> luckDeck;
    public Deque<card> oppoDeck;
    public ArrayList<space>board;

    /**
     * This method is used to setup the game
     * The opportunity knocks and pot luck cards each create their own instance and are
     * placed in their respective  double-ended queues
     * The properties also create each of their own instances and are placed onto the locations found on the board
     */
    public game()
    {
        card oppoCard0 = new cardType1(200,"You inherit £200");
        oppoDeck.push(oppoCard0);
        card oppoCard1 = new cardType1(50,"You have won 2nd prize in a beauty contest, collect £50");
        oppoDeck.push(oppoCard1);
        card oppoCard2 = new cardType2(1,"You are up the creek with no paddle - go back to the Old Creek");
        oppoDeck.push(oppoCard2);
        card oppoCard3 = new cardType1(20,"Student loan refund, collect £50");
        oppoDeck.push(oppoCard3);
        card oppoCard4 = new cardType1(200,"Bank error in your favour. Collect £200");
        oppoDeck.push(oppoCard4);
        card oppoCard5 = new cardType1(-100,"Pay bill for text books of £100");
        oppoDeck.push(oppoCard5);
        card oppoCard6 = new cardType1(-50,"Mega late night taxi bill pay £50");
        oppoDeck.push(oppoCard6);
        card oppoCard7 = new cardType3(0,"Advance to go");
        oppoDeck.push(oppoCard7);
        card oppoCard8 = new cardType1(50,"From sale of Bitcoin you get £50");
        oppoDeck.push(oppoCard8);
        card oppoCard9 = new cardType1(-50,"Bitcoin assets fall - pay off Bitcoin short fall");
        oppoDeck.push(oppoCard9);
        card oppoCard10 = new cardType1(-50,"Pay insurance fee of £50");
        oppoDeck.push(oppoCard10);
        card oppoCard11 = new cardType4("Go to jail. Do not pass GO, do not collect £200");
        oppoDeck.push(oppoCard11);
        card oppoCard12 = new cardType1(25,"Received interest on shares of £25");
        oppoDeck.push(oppoCard12);
        card oppoCard13 = new cardType5("Get out of jail free");
        oppoDeck.push(oppoCard13);
        card oppoCard14 = new cardType6(10,"Pay a £10 fine or take opportunity knocks");
        oppoDeck.push(oppoCard14);

        
        card luckCard0 = new cardType1(50,"Bank pays you divided of £50");
        luckDeck.push(luckCard0);
        card luckCard1 = new cardType1(100,"You have won a lip sync battle. Collect £100");
        luckDeck.push(luckCard1);
        card luckCard2 = new cardType3(39,"Advance to Turing Heights");
        luckDeck.push(luckCard2);
        card luckCard3 = new cardType3(24,"Advance to Han Xin Gardens. If you pass GO, collect £200");
        luckDeck.push(luckCard3);
        card luckCard4 = new cardType6(15,"Fined £15 for speeding");
        luckDeck.push(luckCard4);
        card luckCard5 = new cardType1(150,"Pay university fees of £150");
        luckDeck.push(luckCard5);
        card luckCard6 = new cardType3(15,"Take a trip to Hove station. If you pass GO collect £200");
        luckDeck.push(luckCard6);
        card luckCard7 = new cardType1(150,"Loan matures, collect £150");
        luckDeck.push(luckCard7);
        card luckCard8 = new cardType2(0,"Advance to GO");
        luckDeck.push(luckCard8);
        card luckCard9 = new cardType3(11,"Advance to Skywalker Drive. If you pass GO collect £200");
        luckDeck.push(luckCard9);
        card luckCard10 = new cardType2(30,"Go to jail. Do not pass GO, do not collect £200");
        luckDeck.push(luckCard10);
        card luckCard11 = new cardType6(30,"Drunk in charge of a hoverboard. Fine £30");
        luckDeck.push(luckCard11);
        card luckCard12 = new cardType5("Get out of jail free");
        luckDeck.push(luckCard12);
        
        space go = new space();
        go.setName("go");
        board.add(go);
        space theOldCreek = new property("The Old Creek",60,50,2,10,30,90,160,250);
        board.add(theOldCreek);
        space potLuck = new potLuck();
        board.add(potLuck);
        space gangstersParadise = new property("Gangsters Paradise",60,50,4,20,60,180,320,450);
        board.add(gangstersParadise);
        space incomeTax = new incomeTax();
        board.add(incomeTax);
        space brightonStation = new space();
        brightonStation.setName("Brighton Station");
        board.add(brightonStation);
        space theAngelsDelight = new property("The Angels Delight",100,50,6,30,90,270,400,550);
        board.add(theAngelsDelight);
        space opportunityKnocks = new opportunityKnocks();
        board.add(opportunityKnocks);
        space potterAvenue = new property("Potter Avenue",100,50,6,30,90,270,400,550);
        board.add(potterAvenue);
        space grangerDrive = new property("Grander Drive",120,50,8,40,100,300,450,600);
        board.add(grangerDrive);
        space jail = new space();
        jail.setName("Jail");
        board.add(jail);
        space skywalkerDrive = new property("Skywalker Drive", 140,100,10,50,150,450,625,750);
        board.add(skywalkerDrive);
        space teslaPowerCo = new space();
        teslaPowerCo.setName("Tesla Power Co");
        board.add(teslaPowerCo);
        space wookieHole = new property("Wookie Hole", 140,100,10,50,150,450,625,750);
        board.add(wookieHole);
        space reyLane = new property("Rey Lane", 160,100,12,60,180,5000,700,900);
        board.add(reyLane);
        space hoveStation = new space();
        hoveStation.setName("Hove Station");
        board.add(hoveStation);
        space bishopDrive = new property("Bishop Drive", 180,100,14,70,200,550,750,950);
        board.add(bishopDrive);
        board.add(potLuck);
        space dumhamStreet = new property("Dumham Street", 180,100,14,70,200,550,750,950);
        board.add(dumhamStreet);
        space broylesLane = new property("Broyles Lane", 200,100,16,80,220,600,800,1000);
        board.add(broylesLane);
        space freeParking = new freeParking();
        board.add(freeParking);
        space yueFeiSquare = new property("Yue Fei Square",220,150,18,90,250,700,875,1050);
        board.add(yueFeiSquare);
        board.add(opportunityKnocks);
        space mulanRogue = new property("Mulan Rogue",220,150,18,90,250,700,875,1050);
        board.add(mulanRogue);
        space hanXinGardens = new property("Han Xin Gardens",240,150,20,100,300,750,925,1100);
        board.add(hanXinGardens);
        space falmerStation = new space();
        falmerStation.setName("Falmer Staion");
        board.add(falmerStation);
        space shatnerClose = new property("Shatner Close", 260,150,22,110,330,800,975,1150);
        board.add(shatnerClose);
        space picardAvenue = new property("Picard Avenue", 260,150,22,110,330,800,975,1150);
        board.add(picardAvenue);
        space edisonWater = new space();
        edisonWater.setName("Edison Water");
        board.add(edisonWater);
        space crusherCreek = new property("Crusher Creek",280,150,22,120,360,850,1025,1200);
        board.add(crusherCreek);
        space goToJail = new goToJail();
        board.add(goToJail);
        space SiratMews = new property("Sirat Mews",300,200,26,130,390,900,1100,1275);
        board.add(SiratMews);
        space ghengisCrescent = new property("Ghengis Crescent",300,200,26,130,390,900,1100,1275);
        board.add(ghengisCrescent);
        board.add(potLuck);
        space ibisClose = new property("Ibis Close",320,200,28,150,450,1000,1200,1400);
        board.add(ibisClose);
        space portsladeStation = new space();
        portsladeStation.setName("Portslade Station");
        board.add(portsladeStation);
        board.add(opportunityKnocks);
        space jamesWebbWay = new property("James Webb Way",350,200,35,175,500,1100,1300,1500);
        board.add(jamesWebbWay);
        space superTax = new superTax();
        board.add(superTax);
        space turingHeights = new property("Turing Heights",400,200,50,200,600,1400,1700,2000);
        board.add(turingHeights);
 
     
    }
    

}
