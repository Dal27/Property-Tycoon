package com.mycompany.propertyTycoon;

/**
 *
 * @author Team 42
 * A class specifically designed for a space on the board where
 * the player landing on it must pay a sum of cash
 */
public class superTax extends space{
    
    private String name = "Super Tax";
    private int location = 4;
    private int spacetype = 1;

    /**
     * The money is deducted from the player and given to the bank
     * @param x     The amount of money to be deducted and given to the bank
     * @param bank  The player in control of the flow of assets between the players and bank
     */
    @Override
    public void exec(player x, player bank)
    {
        x.changeCash(-100);
        bank.changeCash(100);
    }
}
