
package com.mycompany.propertyTycoon;

import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Team 42
 */
public class monopoly {

    private boolean isDouble = false;
    private game game;
    private ArrayList<player>players;
    private player bank;
    
    public monopoly()
    {
        bank = new player(9);
        bank.changeCash(48500);
        int playerNum = new Scanner(System.in).nextInt();
        System.out.println("Type number of player");        
        for(int i = 0; i < playerNum; i++)
        {
            players.add(new player(i));
        }        
    }
    
    public void rollDice(player x)
    {  
        if(x.getJailTime() > 0)
        {
            x.changeJailTime(-1);
            return;
        }               
        Random r = new Random();
        int a = r.nextInt(7);
        int b = r.nextInt(7); 
        if((a+b)%2 == 0)
        {
            if(isDouble == false)
            {
                x.move(a+b);
                isDouble = true;
                game.board.get(x.getLocation()).exec(x,bank);
                rollDice(x);                
            }
            else
            {
                x.moveTo(11);
                isDouble = false;
            }
        }
        else
        {
            x.move(a+b);
            isDouble = false;
            game.board.get(x.getLocation()).exec(x,bank);
        }
    }
    
    public void execSpace(player x, space y)
    {
        switch(y.getSpaceType())
        {
            case 1:
                game.board.get(x.getLocation()).exec(x,bank);
            
            case 2:
                drawLuckCard(x,bank);
                
            case 3:
                drawOppoCard(x,bank);                                                            
        }
    }
    
    
    public player bid(property x) throws Exception
    {
        int[] bidCash = null;
        for (int i = 0; i < players.size(); i++) 
        {                        
            bidCash[i] = players.get(i).bid();
        }
        int temp = 0;
        for (int j = 0; j + 1 < bidCash.length; j++)
        {
            for(int k = j + 1; k < bidCash.length; k++)
            {
                if(bidCash[j] < bidCash[k])
                {
                    temp = k;
                }           
            }
        }
        player win = players.get(temp);
        win.changeCash(-bidCash[temp]);
        x.changeOwner(win);
        return win;
    }
    
    public void drawLuckCard(player x, player bank)
    {
        card c = game.luckDeck.pop();
        c.exec(x,bank,x.getLocation(),new freeParking());
        game.luckDeck.addLast(c);       
    }
    
    public void drawOppoCard(player x,player bank)
    {
        card c = game.oppoDeck.pop();
        c.exec(x,bank,x.getLocation(),new freeParking());
        game.oppoDeck.addLast(c);
    }    
}

